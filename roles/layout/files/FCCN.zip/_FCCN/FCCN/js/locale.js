function GetURLParameter(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++) 
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam) 
        {
            return sParameterName[1];
        }
    }
}

function setLocale(value) {
	URL = window.location.href.split("&")[0];
	history.pushState({}, null, URL + "&lang=" + value);
	location.reload();
}
function setLocale_ErrorPage(value) {
	URL = window.location.href.split("?")[0];
	history.pushState({}, null, URL + "?lang=" + value);
	location.reload();
}
function setLocaleLogin(value, index) {
	URL = window.location.href;
	var urlparts1= URL.split('&')[0];
	var urlparts2= URL.split('&')[1];
	history.pushState({}, null, urlparts1+ "&" + "lang=" + value);
	location.reload();
}

function setLocale_initial() {
	URL = window.location.href.split("?")[0];
	history.pushState({}, null, URL);
	location.reload();
}

function changeRecaptchaLanguage(value) {
	document.querySelector('.g-recaptcha').innerHTML = '';
	var script = document.createElement('script');
	script.src = 'https://www.google.com/recaptcha/api.js?hl=' + value;
	script.async = true;
	script.defer = true;
	document.querySelector('head').appendChild(script);
}